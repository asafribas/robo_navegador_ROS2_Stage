import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
from tf_transformations import euler_from_quaternion
import math

class SmartNavigator(Node):
    def __init__(self):
        super().__init__('smart_navigator')
        self.publisher = self.create_publisher(Twist, '/cmd_vel', 10)
        self.scan_sub = self.create_subscription(LaserScan, '/base_scan', self.scan_callback, 10)
        self.odom_sub = self.create_subscription(Odometry, '/odom', self.odom_callback, 10)

        self.laser_data = None
        self.position = None
        self.yaw = None

        self.targets = [(6.0, -1.0), (12.0, 4.0), (19.0, 0.0), (21.0, 2.0), (12.0, -1.0), (12.4, -2.5)]
        self.current_target = 0

        self.state = 'navegar'
        self.timer = self.create_timer(0.1, self.control_loop)

        self.initial_odom = None
        self.offset = None
        self.odom_counter = 0
        self.offset_set = False

        # Variáveis do recuo
        self.recuo_timer = 0
        self.recuo_duracao = 20  # 20 ciclos de 0.1s = 2 segundos

    def scan_callback(self, msg):
        self.laser_data = msg

    def odom_callback(self, msg):
        pos = msg.pose.pose.position
        self.get_logger().info(f"[Odom recebido] x={pos.x:.4f}, y={pos.y:.4f}")

        if not self.offset_set:
            self.odom_counter += 1
            if self.odom_counter >= 10:
                stage_x = 0.0
                stage_y = 0.0

                self.initial_odom = (pos.x, pos.y)
                self.offset = (
                    stage_x - self.initial_odom[0],
                    stage_y - self.initial_odom[1]
                )
                self.offset_set = True
                self.get_logger().info(f"[Offset definido] x={self.offset[0]:.4f}, y={self.offset[1]:.4f}")
            return

        class Position:
            def __init__(self, x, y):
                self.x = x
                self.y = y

        self.position = Position(pos.x + self.offset[0], pos.y + self.offset[1])

        orientation_q = msg.pose.pose.orientation
        orientation_list = [orientation_q.x, orientation_q.y, orientation_q.z, orientation_q.w]
        (_, _, self.yaw) = euler_from_quaternion(orientation_list)

        self.get_logger().info(f"[Odom corrigido] x={self.position.x:.4f}, y={self.position.y:.4f}, yaw={self.yaw:.4f}")

    def control_loop(self):
        if self.laser_data is None or self.position is None or self.yaw is None:
            return

        if self.current_target >= len(self.targets) and self.state != 'recuar':
            self.stop()
            return

        if self.state == 'recuar':
            self.recuo_timer += 0.5
            twist = Twist()
            twist.linear.x = -0.1  # movimento para trás
            self.publisher.publish(twist)
            if self.recuo_timer >= self.recuo_duracao:
                if self.current_target >= len(self.targets):
                    self.stop()
                    self.get_logger().info("Todos os alvos alcançados após recuo.")
                else:
                    self.state = 'navegar'
                    self.get_logger().info("Recuo concluído. Indo para o próximo alvo.")
            return

        target = self.targets[self.current_target]
        dx = target[0] - self.position.x
        dy = target[1] - self.position.y
        distance_to_target = math.hypot(dx, dy)

        if distance_to_target < 0.3:
            self.get_logger().info(f"Alvo {self.current_target + 1} alcançado. Iniciando recuo.")
            self.state = 'recuar'
            self.recuo_timer = 0
            self.current_target += 1
            return

        front = self.get_sector(0, 20)
        left = self.get_sector(60, 100)
        right = self.get_sector(-100, -60)

        front_clear = min(front) > 0.8
        left_clear = min(left) > 0.8
        right_clear = min(right) > 0.8

        if self.state == 'navegar':
            if not front_clear:
                self.state = 'contornar'
            else:
                self.go_to_target(dx, dy)
        elif self.state == 'contornar':
            angle_to_target = math.atan2(dy, dx)
            angle_diff = abs(math.atan2(math.sin(angle_to_target - self.yaw), math.cos(angle_to_target - self.yaw)))
            if front_clear and angle_diff < 0.3:
                self.state = 'navegar'
                self.get_logger().info("Caminho livre! Voltando ao modo navegar.")
            else:
                self.follow_clear_path(left_clear, right_clear)

    def get_sector(self, start_angle, end_angle):
        ranges = list(self.laser_data.ranges)
        ranges = [r if r > 0.0 else float('inf') for r in ranges]
        total = len(ranges)
        start = int((start_angle + 180) / 360.0 * total)
        end = int((end_angle + 180) / 360.0 * total)
        if start <= end:
            sector = ranges[start:end]
        else:
            sector = ranges[start:] + ranges[:end]
        return sector

    def go_to_target(self, dx, dy):
        target_angle = math.atan2(dy, dx)
        angle_diff = math.atan2(math.sin(target_angle - self.yaw), math.cos(target_angle - self.yaw))

        twist = Twist()
        if abs(angle_diff) > 0.2:
            twist.angular.z = 0.5 * angle_diff
        else:
            twist.linear.x = 0.5
            twist.angular.z = 0.0
        self.publisher.publish(twist)

    def follow_clear_path(self, left_clear, right_clear):
        twist = Twist()
        twist.linear.x = 0.1
        if left_clear and not right_clear:
            twist.angular.z = 0.5
        elif right_clear and not left_clear:
            twist.angular.z = -0.5
        elif left_clear and right_clear:
            twist.angular.z = 0.3
        else:
            twist.angular.z = 0.8
        self.publisher.publish(twist)

    def stop(self):
        self.publisher.publish(Twist())
        self.get_logger().info("Robô parado.")

def main(args=None):
    rclpy.init(args=args)
    node = SmartNavigator()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

